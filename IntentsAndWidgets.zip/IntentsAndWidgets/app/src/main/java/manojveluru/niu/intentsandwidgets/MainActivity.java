package manojveluru.niu.intentsandwidgets;
/********************************************************************
 CSCI 522 - Assignment 3 - Semester (Spring) Year - 2019

 Programmer(s): Manoj Veluru, Leela Krishna Vasista Gutta, Sudheeshna Devarapalli
 Section: 1
 TA: Harshith Desamsetti
 Date Due: 02/27/2019

 Purpose: Android application that can be used to display information about 5 (at the least) related topics of your choosing

 *********************************************************************/
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends Activity {

    private Spinner xmlSpin;
    private ImageView pictureIV;
    private String selection1 = null;
    private int pos = 0;
    private int[] img = {R.drawable.ck, R.drawable.dcp, R.drawable.icr,
            R.drawable.pbcd,R.drawable.dbc};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Spinner populated by data from strings.xml file
        xmlSpin = findViewById(R.id.xmlSpinner);

        pictureIV = findViewById(R.id.imageView);

        //create the array adapter with the information
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(getApplicationContext(),
                R.array.spinnerArray,
                R.layout.spinner_view);

        xmlSpin.setAdapter(adapter1);

        xmlSpin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {


                selection1 = parent.getItemAtPosition(position).toString();
                pos = position;
                pictureIV.setImageResource(img[position]);
                Toast.makeText(getApplicationContext(),"The selection is "+selection1,Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }//end onCreate


    //handle button click
    public void getRecipe(View view)
    {

        //create the intent to call NameActivity
        Intent recipeIntent = new Intent(MainActivity.this, SecondActivity.class);
        recipeIntent.putExtra("nameID", selection1);
        recipeIntent.putExtra("position",pos);
        //startActivity();
        startActivity(recipeIntent);
    }

}
